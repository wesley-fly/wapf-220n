

extern void GainTableReadCommand(int client);


extern void GainTableWriteCommand(int client);
