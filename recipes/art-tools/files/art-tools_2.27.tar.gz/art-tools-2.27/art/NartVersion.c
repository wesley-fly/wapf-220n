



#include "NartVersion.h"

static int _Major=2;

static int _Minor=27;

static int _Date=120201;

static int _Time=100000;



int NartVersionMajor()
{
    return _Major;
}

int NartVersionMinor()
{
    return _Minor;
}

int NartVersionDate()
{
    return _Date;
}

int NartVersionTime()
{
    return _Time;
}
