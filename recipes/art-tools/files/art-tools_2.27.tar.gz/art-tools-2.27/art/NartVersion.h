



extern int NartVersionMajor();

extern int NartVersionMinor();

extern int NartVersionDate();

extern int NartVersionTime();
