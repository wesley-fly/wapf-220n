extern void PAPreCalCommand(int client);

