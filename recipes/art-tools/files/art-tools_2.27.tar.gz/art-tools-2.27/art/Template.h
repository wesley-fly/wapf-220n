

extern void TemplateCommand(int client);

extern void TemplateParameterSplice(struct _ParameterList *list);
