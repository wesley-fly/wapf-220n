extern void ConfigGetTPCommand(int client);
extern void ConfigSetTPCommand(int client);
