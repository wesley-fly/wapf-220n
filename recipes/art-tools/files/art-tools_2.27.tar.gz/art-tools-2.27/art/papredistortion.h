
extern int papredistortionSingleTable(struct ath_hal *ah, HAL_CHANNEL *chan, int txChainMask);

