unsigned long FullAddrRead(unsigned long addr);
//unsigned long FullAddrRead();
