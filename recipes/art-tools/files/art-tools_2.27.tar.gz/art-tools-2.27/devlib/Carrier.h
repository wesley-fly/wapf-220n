

extern void CarrierStart(int frequency, unsigned char txchain, int timeout, int (*ison)(), int (*done)());
