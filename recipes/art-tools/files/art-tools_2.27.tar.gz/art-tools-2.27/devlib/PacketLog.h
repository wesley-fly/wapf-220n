


extern void PacketLogEnable(int many);


extern void PacketLog(unsigned int time, int rate, int status, int count);


extern void PacketLogDump();


