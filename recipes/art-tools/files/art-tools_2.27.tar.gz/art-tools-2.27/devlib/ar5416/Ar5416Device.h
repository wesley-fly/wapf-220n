

//
// clear all device control function pointers and set to default behavior
//
extern void Ar5416DeviceSelect();
