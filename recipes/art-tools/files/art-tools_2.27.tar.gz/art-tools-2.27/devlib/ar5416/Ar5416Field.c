


#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

#include "Field.h"
#include "Ar5416Field.h"


#include "merlin_field.h"


void Ar5416FieldSelect()
{
	FieldSelect(_F,sizeof(_F)/sizeof(_F[0]));
}


