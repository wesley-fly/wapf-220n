

//
// Select the ar5416 as the active chip set.
// Makes the generic functions point to the chip specific functions defined here.
//
extern void Ar5416TxDescriptorSelect();
