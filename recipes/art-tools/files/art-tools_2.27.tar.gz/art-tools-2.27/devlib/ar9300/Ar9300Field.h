



extern void Ar9300FieldSelect();

extern void Ar9300_2_0_FieldSelect();

extern void Ar9330_FieldSelect();
