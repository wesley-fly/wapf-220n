
extern int Ar9300TemperatureGet(int);


extern int Ar9300VoltageGet(void);
