

//
// Select the ar9300 as the active chip set.
// Makes the generic functions point to the chip specific functions defined here.
//
extern void Ar9300TxDescriptorSelect();
