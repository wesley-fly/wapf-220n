

extern int print9300Struct(int client, int useDefault);
