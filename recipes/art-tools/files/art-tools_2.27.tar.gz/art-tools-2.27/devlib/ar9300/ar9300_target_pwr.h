
extern int Ar9300EepromGetTargetPwr(int freq, int rateIndex, double *powerOut);
