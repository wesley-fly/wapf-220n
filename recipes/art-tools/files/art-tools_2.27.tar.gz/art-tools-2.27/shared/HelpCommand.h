

extern void HelpCommand(struct _ParameterList *list, int nlist);


extern void HelpParameterSplice(struct _ParameterList *list);
