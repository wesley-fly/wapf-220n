


extern int KeyboardHasInput(void);

extern void KeyboardBeep(void);

//
// get line of input from keyboard
//
extern int KeyboardReadWait(char *buffer, int maxlen);

//
// get line of input from keyboard
//
extern int KeyboardRead(char *buffer, int maxlen);

