
//#ident  "ACI $Id: //depot/sw/branches/narthal_mar2011/dk/mdk/shared/TimeMillisecond.h#1 $, $Header: //depot/sw/branches/narthal_mar2011/dk/mdk/shared/TimeMillisecond.h#1 $"




extern int TimeMillisecond();



